document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('product-container');

    fetch('https://fakestoreapi.com/products')
        .then(res => res.json())
        .then(products => {
            products.forEach(product => {
                const col = document.createElement('div');
                col.className = 'col-md-4 mb-4';
                col.innerHTML = `
                    <div class="card h-100">
                        <img src="${product.image}" class="card-img-top p-3" alt="${product.title}">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">${product.title}</h5>
                            <p class="card-text text-truncate">${product.description}</p>
                            <p class="card-text fw-bold">$${product.price}</p>
                            <button class="btn btn-primary mt-auto" onclick="agregarAlCarrito('${product.title}', ${product.price})">Agregar al carrito</button>
                        </div>
                    </div>
                `;
                container.appendChild(col);
            });
        });
});

function agregarAlCarrito(nombre, precio) {
    Swal.fire({
        icon: 'success',
        title: 'Producto agregado',
        text: `${nombre} ($${precio}) fue agregado al carrito.`,
        timer: 1500,
        showConfirmButton: false
    });
}